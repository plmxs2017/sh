# PagerMaid

PagerMaid is a utility daemon for telegram.

It automates a range of tasks by responding to commands issued to self.

Update channel: https://t.me/PagerMaid

## Installation
See [INSTALL.md](https://git.stykers.moe/users/stykers/repos/pagermaid/browse/INSTALL.md)

## Contact
Use -contact <message> on telegram, and enter the PM that's opened, if you have installation problems email me at stykers@stykers.moe or message me on telegram at [@KatOnKeyboard](https://t.me/KatOnKeyboard).


## Special Thanks
[Amine Oversoul](https://bitbucket.org/oversoul/pagermaid-ui)