#!/bin/sh
while true; do
    clear;
    python3 -m pagermaid;
    echo 'Restarting...';
    sleep 1;
done
