""" PagerMaid web interface startup. """

from pagermaid import logs

logs.info("This module should not be ran directly.")
