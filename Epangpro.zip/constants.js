module.exports = Object.freeze({
  TOKEN: '1091166304:AAH1m6rD7IBbOTmfx5x2pU7uynXRQyY8eSk',
  ARIA_SECRET: 'butterfly',
  ARIA_DOWNLOAD_LOCATION: '/root/Download',
  ARIA_DOWNLOAD_LOCATION_ROOT: '/', //The mountpoint that contains ARIA_DOWNLOAD_LOCATION
  ARIA_FILTERED_DOMAINS: ['yts', 'YTS', 'cruzing.xyz', 'eztv.ag', 'YIFY'], // Prevent downloading from URLs containing these substri$
  ARIA_FILTERED_FILENAMES: ['YIFY'], // Files/top level directories with these substrings in the filename won't be downloaded
  ARIA_PORT: 6820, // Port for aria2c RPC server, if you change this here, make sure to update aria.sh as well
  GDRIVE_PARENT_DIR_ID: '11FUzS91UylfA5y2OCCoCh1Rp2vR-f1Ig',
  SUDO_USERS: [799617962,740265946,792837844,557105344,424212594,766665569,561214169,369522176,711268889],      // Telegram user IDs$
  AUTHORIZED_CHATS: [-1001165937869],        // Telegram chat IDs. Anyone in these chats can use the bot.
  STATUS_UPDATE_INTERVAL_MS: 12000, // A smaller number will update faster, but might cause rate limiting
  DRIVE_FILE_PRIVATE: {
    ENABLED: false,
    EMAILS: ['someMail@gmail.com', 'someOtherMail@gmail.com']
  },
  DOWNLOAD_NOTIFY_TARGET: {  // Information about the web service to notify on download completion.
    enabled: false,   // Set this to true to use the notify functionality
    host: 'hostname.domain',
    port: 80,
    path: '/botNotify'
  },
  COMMANDS_USE_BOT_NAME: {
    ENABLED: true,  // If true, all commands except '/list' has to have the bot username after the command
    NAME: "@Epangpro_bot"
  },
  IS_TEAM_DRIVE: true
});
