#!/bin/bash

## Set the variable below to your Aria password
ARIA_RPC_SECRET="butterfly"
## This is the maximum number of download jobs that will be active at a time. Note that this does not affect the number of concurren$
MAX_CONCURRENT_DOWNLOADS=5
## The port that RPC will listen on
RPC_LISTEN_PORT=6810
aria2c --enable-rpc --rpc-listen-all=false --rpc-listen-port $RPC_LISTEN_PORT --max-concurrent-downloads=$MAX_CONCURRENT_DOWNLOADS -$
echo "Aria2c daemon started"